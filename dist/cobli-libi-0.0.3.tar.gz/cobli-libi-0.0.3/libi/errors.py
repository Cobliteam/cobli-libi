class RetrieveDataError(Exception):
    pass 
